import os
from setuptools import setup
# from nvpy import nvpy

setup(
    name = "kuna",
    version = "1.0",
    author = "parameswara.kuna@gmail.com",
    description = "Demo for packaging",
)
